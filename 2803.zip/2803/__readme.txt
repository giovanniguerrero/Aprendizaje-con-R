-----------------------------------------------------
This resource has been created by Templateswise.com
-----------------------------------------------------

Downloading our resources implies that you have read and accepted our terms of service.
https://www.templateswise.com/terms-of-service/

--> You may not sell or redistribute these resources or make them available for download on others websites without written consent from the owners of Templateswise.com.


If you haven't already, follow us on Facebook & Twitter to get the latest updates!

http://www.facebook.com/templateswise
https://twitter.com/templateswise

Have a wonderful day!

____
Templateswise.com
